@extends('page.layout.main')

@section('title')
UMS-Admin-Section
@endsection

@section('menubar')
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li><a href="/portal">portal</a></li>
          <li><a href="/portal/profile">🚹{{session('username')}}</a></li>
          <li><a href="/portal/admin/userlist">Member List</a></li>        
          <li><a href="/portal/admin/car">Cars Input</a></li>          
          <li class="selected"><a href="/portal/admin/rented">Rented Cars</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
@endsection

@section('site_content')
<div class="sidebar">
        
 <font color="red">
        @foreach($errors->all() as $err)
  ⚠️{{$err}} <br>
@endforeach

<div>
    {{session('msg')}}
  </div>
      </font>





</div>
     <div class="form_settings">

              <table style="width:100%; border-spacing:2;" border="4">
    
            
            <td>Car Name</td>
            <td>Car Brande</td>
            <td>Car Price</td>
            <td>Car Type</td>

          </tr>
          @foreach ($rented as $value)
          <tr>
            
             <td>{{$value->r_name}}</td>
             <td>{{$value->r_brand}}</td>
             <td>{{$value->r_price}}</td>
             <td>{{$value->r_type}}</td>
      
             
           
            
             
            </tr>

          @endforeach

      </div>
      </div>

      @endsection


       <style type="text/css">
        textarea {
font: 100% arial; 
  width: 1200px;
  height: 60px;
}

      </style>





