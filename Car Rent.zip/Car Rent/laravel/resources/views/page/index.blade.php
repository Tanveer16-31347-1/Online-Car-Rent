<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<a href="">Admin</a> |
	<a href="">User</a>
</body>
</html>