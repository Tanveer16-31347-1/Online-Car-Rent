@extends('page.layout.main')

@section('title')
UMS-Home
@endsection

@section('menubar')
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li class="selected" ><a href="/home">Home</a></li>
                    <li><a href="/login">Login</a></li>
          <li><a href="/registration">Register</a></li>
        </ul>
@endsection

