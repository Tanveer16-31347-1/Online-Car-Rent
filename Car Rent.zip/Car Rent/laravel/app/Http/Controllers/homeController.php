<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\User;
use Validator;
use App\Http\Requests\StudentRequest;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function sessionCheck($req){
        if($req->session()->has('username')){
            return true;
        }else{
            return false;
        }
    }

     public function index(Request $req){

       


    

                 //echo $notice;

                 return view('page.home.home');
 

        
        }

   


}








