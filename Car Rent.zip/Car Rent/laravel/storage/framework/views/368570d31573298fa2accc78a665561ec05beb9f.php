<?php $__env->startSection('title'); ?>
UMS-Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li class="selected" ><a href="/home">Home</a></li>
          <li><a href="examples.html">Examples</a></li>
          <li ><a href="/page/admin">A Page</a></li>
          <li><a href="another_page.html">Another Page</a></li>
          <li><a href="contact.html">Contact Us</a></li>
          <li><a href="/login">Login</a></li>
          <li><a href="/registration">Register</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
        
      </div>
      <div id="content">
        <!-- insert the page content here -->
        <h1>NOTICE DETAILS</h1>
        
        
        

      <div class="form_settings">

         <table style="width:100%; border-spacing:2;" border="4">
          <tr><td>ID</td><td>Title</td><td>description</td></tr>
          <?php $__currentLoopData = $allnotice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($w->n_id); ?></td>
             <td><?php echo e($w->n_title); ?></td>
             <td><?php echo e($w->n_description); ?></td>
            
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        
      </div>
      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\UMS\laravel\resources\views/page/home/allnoticeDetails.blade.php ENDPATH**/ ?>