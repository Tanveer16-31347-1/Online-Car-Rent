<?php $__env->startSection('title'); ?>
UMS-portal-tsf
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li><a href="/portal">portal</a></li>
          <li><a href="">🚹<?php echo e(session('username')); ?></a></li>
          <li class="selected"><a href="/portal/faculty/tsf">update TSF</a></li>
         <li><a href="/portal/preRegistration">pre registration</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
        
 <font color="red">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  ⚠️<?php echo e($err); ?> <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div>
    <?php echo e(session('msg')); ?>

  </div>
      </font>





</div>
      <div id="content">
        
        
       
      <form  method="post">
        
  <p><textarea placeholder="e.g Sunday #atp3 8-11 #COA1-2 #consulting *"  name="t_sun"></textarea></p>
  <p><textarea placeholder="e.g Monday #atp3 8-11 #COA1-2 #consulting *" name="t_mon"></textarea></p>
  <p><textarea placeholder="e.g Tuesday #atp3 8-11 #COA1-2 #consulting " name="t_tue"></textarea></p>
  <p><textarea placeholder="e.g Wednesday #atp3 8-11 #COA1-2 #consulting " name="t_wed"></textarea></p>
  <div class="form_settings">
  <p ><span></span><input class="submit" type="submit" name="name" value="Submit" /></p>

</form>
        </div>
        
        
      </div>
      <?php $__env->stopSection(); ?>


       <style type="text/css">
        textarea {
font: 100% arial; 
  width: 1200px;
  height: 60px;
}

      </style>
<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\UMS\laravel\resources\views/page/portal/faculty/tsfSubmit.blade.php ENDPATH**/ ?>