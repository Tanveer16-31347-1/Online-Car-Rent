<?php $__env->startSection('title'); ?>
UMS-Admin-Section
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li><a href="/portal">portal</a></li>
          <li><a href="/portal/profile">🚹<?php echo e(session('username')); ?></a></li>
          <li><a href="/portal/admin/userlist">Member List</a></li>        
          <li><a href="/portal/admin/car">Cars Input</a></li>          
          <li class="selected"><a href="/portal/admin/rented">Rented Cars</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
        
 <font color="red">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  ⚠️<?php echo e($err); ?> <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div>
    <?php echo e(session('msg')); ?>

  </div>
      </font>





</div>
     <div class="form_settings">

              <table style="width:100%; border-spacing:2;" border="4">
    
            
            <td>Car Name</td>
            <td>Car Brande</td>
            <td>Car Price</td>
            <td>Car Type</td>

          </tr>
          <?php $__currentLoopData = $rented; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            
             <td><?php echo e($value->r_name); ?></td>
             <td><?php echo e($value->r_brand); ?></td>
             <td><?php echo e($value->r_price); ?></td>
             <td><?php echo e($value->r_type); ?></td>
      
             
           
            
             
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      </div>

      <?php $__env->stopSection(); ?>


       <style type="text/css">
        textarea {
font: 100% arial; 
  width: 1200px;
  height: 60px;
}

      </style>






<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Car Rent\laravel\resources\views/page/portal/admin/rented.blade.php ENDPATH**/ ?>