<!DOCTYPE html>
<html>
<head>
	<title>Student Details</title>
</head>
<body>
	
	<a href="/home">Back</a> |
	<a href="/logout">Logout</a>
	
	<table>
		<tr>
			<td>ID : </td>
			<td><?php echo e($std[0]); ?></td>
		</tr>
		<tr>
			<td>Name : </td>
			<td><?php echo e($std[1]); ?></td>
		</tr>
		<tr>
			<td>CGPA :</td>
			<td><?php echo e($std[2]); ?></td>
		</tr>
		<tr>
			<td>DEPT : </td>
			<td><?php echo e($std[3]); ?></td>
		</tr>
	</table>
	
</body>
</html><?php /**PATH C:\Xampp\htdocs\laravel\lavavel\resources\views/home/details.blade.php ENDPATH**/ ?>