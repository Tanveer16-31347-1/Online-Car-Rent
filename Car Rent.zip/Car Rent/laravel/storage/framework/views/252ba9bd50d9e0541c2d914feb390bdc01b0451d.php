<?php $__env->startSection('title'); ?>
UMS-portal
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li ><a href="/portal">portal</a></li>
         <li>><a href="/portal/profile">🚹<?php echo e(session('username')); ?></a></li>
          <li class="selected" ><a href="/portal/member/carlist">Carlist</a></li>
  
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
        
      </div>
      <div id="content">
        <!-- insert the page content here -->
        <h1>portal view for member</h1>
        <?php echo e(session('type')); ?> : <?php echo e(session('username')); ?>

        
        

      <table style="width:100%; border-spacing:2;" border="4">
    
            
            <td>Car Name</td>
            <td>Car Brande</td>
            <td>Car Price</td>
            <td>Car Type</td>
            <td>Action</td>
          </tr>
          <?php $__currentLoopData = $carlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            
             <td><?php echo e($value->c_name); ?></td>
             <td><?php echo e($value->c_brand); ?></td>
             <td><?php echo e($value->c_price); ?></td>
             <td><?php echo e($value->c_type); ?></td>
             <td><a href="<?php echo e(route('member.updateMember',$value->c_id )); ?>">ADD</td>
             
           
            
             
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        
      </div>
      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Car Rent\laravel\resources\views/page/portal/member/carlist/carlistshow.blade.php ENDPATH**/ ?>