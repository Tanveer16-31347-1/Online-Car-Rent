<?php $__env->startSection('title'); ?>
UMS-portal-Pre Registration
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li><a href="/portal">portal</a></li>
          <li><a href="/portal/profile">🚹<?php echo e(session('username')); ?></a></li>
          <li><a href="/portal/faculty/tsf">update TSF</a></li>
          <li class="selected"><a href="/portal/preRegistration">pre registration</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>

<div class="sidebar">
        <font color="red">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  âš ï¸<?php echo e($err); ?> <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div>
    <?php echo e(session('msg')); ?>

  </div>
      </font>

      </div>
<div class="sidebar">
        
 <font color="red">
        

<div>
    <?php echo e(session('msg')); ?>

  </div>
      </font>


      </div>
      
        <!-- insert the page content here -->
        
       
<!-- table starts -->


<form method="post">

  <table border="1">
    <tr><td colspan="9">Offered Cources</td></tr>
    <tr align="center">
      <td>id</td>
      <td>name</td>
      <td>department</td>
       <td colspan="3">Semester</td>
       <td>Section</td>
      <td>Status</td>
      <td>ACTION</td>
    </tr>

    <?php $__currentLoopData = $registerReg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
      <tr>
        <td><?php echo e($v->c_admin_id); ?></td>
        <td><input type="text" name="c_register_name" value="<?php echo e($v->c_admin_name); ?>" readonly="readonly" ></td>
        <td><input type="text" name="c_register_dept" value="<?php echo e($v->c_admin_dept); ?>" readonly="readonly" ></td>
        
       
         <td colspan="3"> 
          
               <select name="c_register_semester" id="mySelect2">
                <?php

                for ($x = 0; $x <(count($s_semester)); $x++) {
    echo "<option value='".$s_semester[$x]->s_type." ".$s_semester[$x]->s_duration ."'>".$s_semester[$x]->s_type." ".$s_semester[$x]->s_duration."</option>";
 }
       ?>

  
              </select>
           
        </td>
          </div>

        <td>
            <p><input class="notice" type="text" name="c_register_section" value=""></p>
        </td>

        <td>
             <select name="c_register_status" >
               
               
    <option value="0" > PUBLISH</option>";
    <option value="1" > CREATE ONLY</option>";
 

  
              </select>
        </td>
                  
        <td>

            
        <input type="submit" name="submit" value="SUBMIT">
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </td>
      </tr>
    </table>
   

   
    
   
  </form>


   





  




<!-- table ends -->



        
        
     
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\UMS\laravel\resources\views/page/portal/preReg/register/preReg.blade.php ENDPATH**/ ?>