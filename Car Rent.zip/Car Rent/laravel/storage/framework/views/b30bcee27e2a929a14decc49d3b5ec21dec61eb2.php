<?php $__env->startSection('title'); ?>
UMS-portal-tsf
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li><a href="/portal">portal</a></li>
          <li><a href="/portal/profile">🚹<?php echo e(session('username')); ?></a></li>
          <li><a href="/portal/faculty/tsf">update TSF</a></li>
          <li class="selected"><a href="<?php echo e(route('tsfview.index',session('username') )); ?>">View Tsf</a></li>
          <li><a href="/portal/preRegistration">pre registration</a></li>
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>

      




        
       
   
        <?php
            $t_sun = preg_split ("/#/", $tsf[0]->t_sun);
            $t_mon = preg_split ("/#/", $tsf[0]->t_mon);
            $t_tue = preg_split ("/#/", $tsf[0]->t_tue);
            $t_wed = preg_split ("/#/", $tsf[0]->t_wed);
       ?>
<table align="center" cellspacing="15" class='pre_split'> 
  
  <tr bgcolor="#c2c0c0"> 
    <td>DAY</td>
    <td colspan="2" ><font color="white"><strong>TSF<sub>of</sub> : </strong></font><mark>
      <?php echo e($tsf[0]->t_name); ?></mark></td> 
  </tr>
  
  <tr bgcolor="#1bf798">
      <?php
foreach ($t_sun as $value) {
  
  echo "<td class='pre_split'>".$value."</td>";
}
       ?>

       </tr>





       <tr bgcolor="#1bf7f7" >
      <?php
foreach ($t_mon as $value) {
  
  echo "<td class='pre_split'>".$value."</td>";
}
       ?>

       </tr> 


       <tr bgcolor="#faa693">
      <?php
foreach ($t_tue as $value) {
  
  echo "<td class='pre_split'>".$value."</td>";
}
       ?>

       </tr> 


       <tr bgcolor="#f285d9" >
      <?php
foreach ($t_wed as $value) {
  
  echo "<td class='pre_split'>".$value."</td>";
}
       ?>

       </tr>





</table>






            

           



            
           
      
       
        
        
      
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\UMS\laravel\resources\views/page/portal/tsfView/tsfView.blade.php ENDPATH**/ ?>