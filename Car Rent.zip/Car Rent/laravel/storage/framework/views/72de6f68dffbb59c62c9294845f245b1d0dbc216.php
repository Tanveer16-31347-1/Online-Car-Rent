<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>Login page</h1>
	
	<form method="post">
	<!--	<?php echo e(csrf_field()); ?>-->
	<!--<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> -->
		<?php echo csrf_field(); ?>
		<table>
			<tr>
				<td>Username</td>
				<td><input type="text" name="uname"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" name="submit" value="Submit"></td>
			</tr>
		</table>
	</form>
	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php echo e($err); ?> <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<div>
		<?php echo e(session('msg')); ?>

	</div>
</body>
</html><?php /**PATH C:\Xampp\htdocs\UMS\laravel\resources\views/login/index.blade.php ENDPATH**/ ?>