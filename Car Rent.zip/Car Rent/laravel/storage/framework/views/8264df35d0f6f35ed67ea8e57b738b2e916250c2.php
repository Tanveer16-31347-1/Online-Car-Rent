<?php $__env->startSection('title'); ?>
UMS-portal-SectionDetails
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menubar'); ?>
<ul id="menu">
          <!-- put class="selected" in the li tag for the selected page - to highlight which page you're on -->
          <li><a href="/home">Home</a></li>
          <li><a href="/portal">portal</a></li>
          <li><a href="/portal/profile">🚹<?php echo e(session('username')); ?></a></li>
          <li class="selected"><a href="<?php echo e(route('student.scheduleDetails',$studentCourseDetails[0]->c_student_id )); ?>">Schedule Details</a></li>
		 <li><a href="<?php echo e(route('student.scheduleDetails.uploadSlide',$studentCourseDetails[0]->c_student_id )); ?>">upload Assignment</a></li>
		 <li><a href="/portal/student/notice">Notice</a></li>
		 <li><a href="/portal/student/tsf_view">View TSF</a></li>
		 <li><a href="/portal/preRegistration">pre registration</a></li>
	
          <li><a href="/logout">Logout</a></li>
        </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('site_content'); ?>
<div class="sidebar">
         <font color="red">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  ⚠️<?php echo e($err); ?> <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div>
    <?php echo e(session('msg')); ?>

  </div>
      </font>
      </div>
      
        <!-- insert the page content here -->
        

        

  
   
    
<table align="left" cellspacing="10" > 
  <tr >
    <?php $__currentLoopData = $studentCourseDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    
       
       <td bgcolor="#1bf798"> COURSE: <mark><?php echo e($s->c_student_name); ?></mark></td>
       <td bgcolor="#c2c0c0">ID: <mark><?php echo e($s->c_student_id); ?></mark></td>
       <td bgcolor="#22e0e0">SECTION: <mark><?php echo e($s->c_student_section); ?></mark></td>
       <td bgcolor="#faa693">FACULTY: <mark><?php echo e($s->c_student_faculty); ?></mark></td>
       
       
         
        
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tr>
 
	
	
	
  </table>






        
        
     
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('page.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\UMS\laravel\resources\views/page/portal/student/scheduleDetails.blade.php ENDPATH**/ ?>