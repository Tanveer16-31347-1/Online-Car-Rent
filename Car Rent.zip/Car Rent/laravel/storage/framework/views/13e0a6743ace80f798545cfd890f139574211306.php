<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<a href="/page/admin">Admin</a> |
	<a href="/page/user">User</a>
</body>
</html><?php /**PATH C:\Xampp\htdocs\UMS\laravel\resources\views/page/index.blade.php ENDPATH**/ ?>